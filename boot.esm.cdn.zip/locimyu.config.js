// locimyu.config.js — injected before gauth.module.js & boot.esm.cdn.js
window.GIS_CLIENT_ID = "595200751510-ncahnf7edci6b9925becn5to49r6cguv.apps.googleusercontent.com";
window.GIS_API_KEY   = "AIzaSyCUnTCr5yWUWPdEXST9bKP1LpgawU5rIbI";
window.GIS_SCOPES = [
  "https://www.googleapis.com/auth/drive.readonly",
  "https://www.googleapis.com/auth/drive.file",
  "https://www.googleapis.com/auth/drive.metadata.readonly",
  "https://www.googleapis.com/auth/spreadsheets"
].join(' ');
// Optional: window.GIS_PROMPT = "consent";
// Optional: window.GIS_HINT = "<youremail@example.com>";
