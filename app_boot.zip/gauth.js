// gauth.js - classic-safe stub (2025-10-07)
// This file intentionally does nothing. The real module is 'gauth.module.js'.
// If you see this being executed, remove any <script src="./gauth.js"> tags from HTML.
console && console.warn && console.warn('[gauth] classic stub loaded. Use app_boot.js (module) to import gauth.module.js.');
