// content.js (silent placeholder)
(function(){ try {
  if (!window.__LM_DEV) window.__LM_DEV = {};
  console.log('[content.js] ready');
} catch(e){} })();
